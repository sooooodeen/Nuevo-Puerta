<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loginmanager";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inputUsername = $_POST['username'] ?? null;
    $inputPassword = $_POST['password'] ?? null;

    if (!$inputUsername || !$inputPassword) {
        die("Invalid login attempt.");
    }

    $role = null;
    $id = null;
    $password_hash = null;

    // Check in users table (username matched against account_number)
    $stmt = $conn->prepare("SELECT id, password FROM user_accounts WHERE username = ?");
    $stmt->bind_param("s", $inputUsername);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $password_hash);
        $stmt->fetch();
        $role = "user";
    }
    $stmt->close();

    // Check in agents table
    if (!$role) {
        $stmt = $conn->prepare("SELECT id, password FROM agent_accounts WHERE username = ?");
        $stmt->bind_param("s", $inputUsername);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $password_hash);
            $stmt->fetch();
            $role = "agent";
        }
        $stmt->close();
    }

    // Check in admins table
    if (!$role) {
        $stmt = $conn->prepare("SELECT id, password FROM admin_accounts WHERE username = ?");
        $stmt->bind_param("s", $inputUsername);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $password_hash);
            $stmt->fetch();
            $role = "admin";
        }
        $stmt->close();
    }

    if (!$role) {
        die("Invalid credentials.");
    }

    if (password_verify($inputPassword, $password_hash)) {
        $_SESSION['role'] = $role;
    
        switch ($role) {
            case "user":
                $_SESSION['user_id'] = $id;
                header("Location: userdashboard/userdashboard.php");
                break;
            case "agent":
                $_SESSION['agent_id'] = $id;
                header("Location: agentdashboard.php");
                break;
            case "admin":
                $_SESSION['admin_id'] = $id;
                header("Location: admindashboard.php");
                break;
        }
        exit();
    } else {
        echo "Invalid password.";
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | El Nuevo Puerta Real Estate</title>
    <style>
        /* General styling */
        body {
            background: url('assets/bgr.png') no-repeat center center/cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            flex-direction: column;
            font-family: 'Arial', sans-serif;
        }

        /* Logo */
        .logo {
            width: 300px;
            margin-bottom: 20px;
        }

        /* Role selector */
        label {
            font-size: 18px;
            color: #ffffff;
            font-weight: bold;
            margin-bottom: 10px;
        }

        select {
            width: 300px;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #ffffff;
            border-radius: 30px;
            font-size: 16px;
            background: rgba(255, 255, 255, 0.8);
            color: #333;
            cursor: pointer;
        }

        select:focus {
            outline: none;
            border-color: #79974a;
        }

        /* Form container */
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        /* Input fields */
        input {
            display: block;
            width: 270px;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #ffffff;
            border-radius: 30px;
            font-size: 16px;
            background: rgba(255, 255, 255, 0.8);
        }

        input::placeholder {
            color: #555;
        }

        input:focus {
            outline: none;
            border-color: #79974a;
        }

        /* Password container */
        .password-container {
            position: relative;
            width: 270px;
        }

        /* Forgot password link */
        .forgot-password {
            position: absolute;
            right: 10px;
            bottom: 10px;
            font-size: 14px;
            color: #ffffff;
            text-decoration: none;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }

        /* Login button */
        button {
            width: 150px;
            padding: 12px;
            background: #79974a;
            color: #ffffff;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #5d7c38;
        }

        /* Guest login link */
        .guest-login {
            display: block;
            margin-top: 20px;
            font-size: 16px;
            color: #ffffff;
            font-weight: bold;
            text-decoration: none;
        }

        .guest-login span {
            text-decoration: underline;
        }

        /* Hide fields dynamically */
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <img src="assets/logo.png" alt="El Nuevo Puerta Real Estate Logo" class="logo">

    <form id="loginForm" action="login.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" placeholder="Username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Password" required>

        <button type="submit">Login</button>
    </form>
</body>
</html>
